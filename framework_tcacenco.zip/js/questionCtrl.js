app.controller('questionCtrl', function($scope) {
    $scope.typeOfQuestions = [
        "Во сколько заезд?",
        "Как получить скидку?",
        "Гаранитируете ли вы приватность ваших гостей?",
        "У вас бассейн с подогревом?"
    ];
});